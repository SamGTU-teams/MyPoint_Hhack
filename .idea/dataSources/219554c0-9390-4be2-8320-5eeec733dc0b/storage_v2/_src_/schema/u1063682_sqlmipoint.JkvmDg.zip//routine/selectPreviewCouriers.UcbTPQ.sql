create
    definer = u1063682_one_cod@`%` procedure selectPreviewCouriers(IN temp_order int)
begin
    declare lat_order float;
    declare lon_order float;
    declare id_building int;
    declare address_order text;
    set lat_order = (select end_lat from tempOrder where id = temp_order);
    set lon_order = (select end_lon from tempOrder where id = temp_order);
    set id_building = (select stock from tempOrder where id = temp_order);
    set address_order = (select finish_address from tempOrder where id = temp_order);

    select result.temp_order                                 as id_order,
           result.id_building                                as id_building,
           result.id_courier                                 as id_courier,
           result.address_building                           as address_building,
           result.courier_name                               as courier_name,
           result.courier_rating                             as courier_rating,
           result.distance / 1000                            as distance,
           sec_to_time(result.distance / result.speed * 3.6) as travel_time,
           lat_order,
           lon_order,
           address_order
    from (select temp_order,
                 buildings_set.id                              as id_building,
                 couriers_vehicles.id                          as id_courier,
                 buildings_set.address                         as address_building,
                 couriers_vehicles.name                        as courier_name,
                 couriers_vehicles.rating                      as courier_rating,
                 buildings_set.distance +
                 min(calculateDistance(buildings_set.lat, couriers_vehicles.lat, buildings_set.lon,
                                       couriers_vehicles.lon)) as distance,
                 couriers_vehicles.speed                       as speed
          from (select id,
                       latitude                                                     as lat,
                       longitude                                                    as lon,
                       address,
                       calculateDistance(lat_order, latitude, lon_order, longitude) as distance
                from buildings
                where id = id_building) as buildings_set,
               (select c.id             as id,
                       c.name           as name,
                       c.rating         as rating,
                       c.last_longitude as lon,
                       c.last_latitude  as lat,
                       c.busy           as busy,
                       c.online         as online,
                       v.speed          as speed
                from couriers c
                         inner join vehicles v on v.id = c.vehicle) as couriers_vehicles
          where !couriers_vehicles.busy
            and couriers_vehicles.online
          group by couriers_vehicles.id) as result
    order by travel_time;
end;

