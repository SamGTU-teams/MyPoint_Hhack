create
    definer = u1063682_one_cod@`%` procedure loadGeoposition(IN id_courier int, IN lat float, IN lon float)
begin
    update couriers
    set last_time      = current_time,
        last_latitude  = lat,
        last_longitude = lon
    where id = id_courier;
end;

